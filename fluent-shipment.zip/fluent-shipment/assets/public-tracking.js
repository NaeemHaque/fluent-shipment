/*!
 * Fluent Shipment Public Tracking
 * Version: 1.0.0
 */(function(i){const u={init:function(){this.bindEvents(),this.checkUrlParams()},bindEvents:function(){i("#fs-tracking-form").on("submit",this.handleFormSubmit.bind(this)),i("#fs-tracking-input").on("keypress",function(t){t.which===13&&(t.preventDefault(),i("#fs-tracking-form").trigger("submit"))})},checkUrlParams:function(){const s=new URLSearchParams(window.location.search).get("tracking");s&&s.trim()&&i("#fs-tracking-input").val(s.trim())},handleFormSubmit:function(t){t.preventDefault();const s=i("#fs-tracking-input").val().trim();if(!s){this.showError("Please enter a tracking number");return}const a=this.updateUrlParam(window.location.href,"tracking",s);window.location.href=a},handleRealtimeSearch:function(){const t=i("#fs-tracking-input").val().trim();t.length<6||this.performAjaxSearch(t)},performAjaxSearch:function(t){this.showLoading(),i.ajax({url:fluentShipmentPublic.ajaxUrl,method:"POST",data:{action:"fluent_shipment_track",tracking_number:t,nonce:fluentShipmentPublic.nonce},success:this.handleAjaxSuccess.bind(this),error:this.handleAjaxError.bind(this),complete:this.hideLoading.bind(this)})},handleAjaxSuccess:function(t){t.success?this.displayResults(t.data):this.showError(t.data.message||fluentShipmentPublic.strings.no_results)},handleAjaxError:function(t,s,a){console.error("Tracking AJAX Error:",a),this.showError(fluentShipmentPublic.strings.error)},displayResults:function(t){const s=this.buildResultsHtml(t);i("#fs-tracking-results").html(s).show(),i("html, body").animate({scrollTop:i("#fs-tracking-results").offset().top-20},500)},buildResultsHtml:function(t){const s=t.shipment,a=t.events;let e='<div class="fs-tracking-success">';return e+=`
                <div class="fs-shipment-header">
                    <div class="fs-shipment-info">
                        <div class="fs-shipment-title">
                            Tracking Number: <span class="fs-tracking-number">${this.escapeHtml(s.tracking_number)}</span>
                        </div>
                        <div class="fs-current-status">
                            <span class="fs-status-label ${this.getStatusClass(s.current_status)}">
                                ${this.getStatusLabel(s.current_status)}
                            </span>
                        </div>
                    </div>
                </div>
            `,e+='<div class="fs-shipment-details"><div class="fs-detail-grid">',s.carrier&&(e+=`
                    <div class="fs-detail-item">
                        <label>Carrier:</label>
                        <span>${this.escapeHtml(this.capitalizeFirst(s.carrier))}</span>
                    </div>
                `),s.estimated_delivery&&(e+=`
                    <div class="fs-detail-item">
                        <label>Estimated Delivery:</label>
                        <span>${this.formatDate(s.estimated_delivery)}</span>
                    </div>
                `),e+=`
                <div class="fs-detail-item">
                    <label>Ship Date:</label>
                    <span>${this.formatDate(s.created_at)}</span>
                </div>
            `,s.delivery_address&&(e+=`
                    <div class="fs-detail-item fs-detail-full">
                        <label>Delivery Address:</label>
                        <span>${this.escapeHtml(s.delivery_address)}</span>
                    </div>
                `),e+="</div></div>",a&&a.length>0&&(e+='<div class="fs-tracking-timeline">',e+='<h4 class="fs-timeline-title">Tracking History</h4>',e+='<div class="fs-timeline">',a.forEach((n,r)=>{const c=r===0,l=r===a.length-1,o=n.is_milestone;e+=`
                        <div class="fs-timeline-item ${c?"fs-timeline-current":""} ${o?"fs-timeline-milestone":""}">
                            <div class="fs-timeline-marker">
                                <div class="fs-timeline-dot"></div>
                                ${l?"":'<div class="fs-timeline-line"></div>'}
                            </div>
                            <div class="fs-timeline-content">
                                <div class="fs-timeline-header">
                                    <span class="fs-timeline-status ${this.getStatusClass(n.status)}">
                                        ${this.getStatusLabel(n.status)}
                                    </span>
                                    <span class="fs-timeline-date">
                                        ${n.formatted_date}
                                    </span>
                                </div>
                    `,n.description&&(e+=`<div class="fs-timeline-description">${this.escapeHtml(n.description)}</div>`),n.location&&(e+=`<div class="fs-timeline-location">📍 ${this.escapeHtml(n.location)}</div>`),e+="</div></div>"}),e+="</div></div>"),e+="</div>",e},showLoading:function(){i("#fs-tracking-loading").show(),i("#fs-tracking-results").hide();const t=i(".fs-search-button");t.prop("disabled",!0),t.find(".fs-search-text").hide(),t.find(".fs-search-loading").show()},hideLoading:function(){i("#fs-tracking-loading").hide();const t=i(".fs-search-button");t.prop("disabled",!1),t.find(".fs-search-text").show(),t.find(".fs-search-loading").hide()},showError:function(t){const s=`
                <div class="fs-tracking-error">
                    <div class="fs-error-icon">📦</div>
                    <h3>Error</h3>
                    <p>${this.escapeHtml(t)}</p>
                </div>
            `;i("#fs-tracking-results").html(s).show()},debounce:function(t,s){let a;return function(...n){const r=()=>{clearTimeout(a),t(...n)};clearTimeout(a),a=setTimeout(r,s)}},updateUrlParam:function(t,s,a){let e="",n=t.split("?"),r=n[0],c=n[1],l="";if(c){n=c.split("&");for(let d=0;d<n.length;d++)n[d].split("=")[0]!=s&&(e+=l+n[d],l="&")}let o=l+""+s+"="+a;return r+"?"+e+o},escapeHtml:function(t){const s={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"};return t.replace(/[&<>"']/g,function(a){return s[a]})},capitalizeFirst:function(t){return t.charAt(0).toUpperCase()+t.slice(1)},formatDate:function(t){return new Date(t).toLocaleDateString("en-US",{year:"numeric",month:"short",day:"numeric"})},getStatusLabel:function(t){return{pending:"Pending",processing:"Processing",shipped:"Shipped",in_transit:"In Transit",out_for_delivery:"Out for Delivery",delivered:"Delivered",failed:"Delivery Failed",cancelled:"Cancelled",returned:"Returned",exception:"Exception"}[t]||this.capitalizeFirst(t.replace("_"," "))},getStatusClass:function(t){return{pending:"status-pending",processing:"status-processing",shipped:"status-shipped",in_transit:"status-transit",out_for_delivery:"status-delivery",delivered:"status-delivered",failed:"status-failed",cancelled:"status-cancelled",returned:"status-returned",exception:"status-exception"}[t]||"status-default"}};i(document).ready(function(){i("#fluent-shipment-tracking").length&&u.init()}),window.FluentShipmentTracking=u})(jQuery);
