<?php

/**
 * @var $router FluentFramework\Http\Router\Router
 */

use FluentShipment\App\Http\Controllers\DashboardController;
use FluentShipment\App\Http\Controllers\ShipmentController;
use FluentShipment\App\Http\Controllers\RiderController;
use FluentShipment\App\Http\Controllers\SettingsController;

$router->get('/dashboard', [DashboardController::class, 'index']);

$router->prefix('/shipments')->group(function () use ($router) {
    $router->get('/', [ShipmentController::class, 'index']);
    $router->post('/', [ShipmentController::class, 'store']);
    $router->get('/stats', [ShipmentController::class, 'stats']);
    
    // FluentCart integration
    $router->post('/import/fluent-cart', [ShipmentController::class, 'importFromFluentCart']);
    $router->post('/from-fluent-cart-order/{orderId}', [ShipmentController::class, 'createFromFluentCartOrder']);
    
    // Bulk operations
    $router->post('/bulk/update-status', [ShipmentController::class, 'bulkUpdateStatus']);
    
    // Individual shipment operations
    $router->get('/{id}', [ShipmentController::class, 'show']);
    $router->put('/{id}/status', [ShipmentController::class, 'updateStatus']);
    $router->put('/{id}/tracking', [ShipmentController::class, 'updateTrackingNumber']);
    $router->delete('/{id}', [ShipmentController::class, 'delete']);
    
    // Tracking events
    $router->get('/{id}/tracking-events', [ShipmentController::class, 'trackingEvents']);
    $router->post('/{id}/tracking-events', [ShipmentController::class, 'addTrackingEvent']);
});

$router->prefix('/riders')->group(function () use ($router) {
    $router->get('/', [RiderController::class, 'index']);
    $router->post('/', [RiderController::class, 'store']);
    $router->get('/stats', [RiderController::class, 'stats']);
    $router->get('/active', [RiderController::class, 'getActiveRiders']);
    $router->get('/search', [RiderController::class, 'search']);
    $router->post('/bulk/update-status', [RiderController::class, 'bulkUpdateStatus']);
    
    // Individual rider operations
    $router->get('/{id}', [RiderController::class, 'show']);
    $router->put('/{id}', [RiderController::class, 'update']);
    $router->put('/{id}/status', [RiderController::class, 'updateStatus']);
    $router->put('/{id}/rating', [RiderController::class, 'updateRating']);
    $router->delete('/{id}', [RiderController::class, 'delete']);
});

$router->prefix('/settings')->group(function () use ($router) {
    $router->get('/email', [SettingsController::class, 'getEmailSettings']);
    $router->post('/email', [SettingsController::class, 'updateEmailSettings']);
    $router->post('/email/test', [SettingsController::class, 'testEmail']);
    $router->get('/smtp', [SettingsController::class, 'getSmtpSettings']);
    $router->post('/smtp', [SettingsController::class, 'updateSmtpSettings']);

    // General settings
    $router->get('/general', [SettingsController::class, 'getGeneralSettings']);
    $router->post('/general', [SettingsController::class, 'updateGeneralSettings']);
});
