<?php

/**
 * Add only the plugin specific bindings here.
 * 
 * $app
 * @var FluentShipment\App\Foundation\Application
 */

// Note: To enable async requests, uncomment the line below

// (new PluginNamespace\Framework\Http\Client)->registerAsyncRequestHandler();